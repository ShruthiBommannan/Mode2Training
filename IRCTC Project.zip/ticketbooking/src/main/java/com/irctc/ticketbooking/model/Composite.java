package com.irctc.ticketbooking.model;

import java.io.Serializable;
import java.time.LocalDate;

public class Composite implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	String trainId;
	LocalDate date;

	public Composite() {
		super();
	}

	public Composite(String trainId, LocalDate date) {
		super();
		this.trainId = trainId;
		this.date = date;

	}

	public String getTrainId() {
		return trainId;
	}

	public void setTrainId(String trainId) {
		this.trainId = trainId;
	}

	public LocalDate getDate() {
		return date;
	}

	public void setDate(LocalDate date) {
		this.date = date;
	}

}
