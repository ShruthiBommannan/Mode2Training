package com.irctc.ticketbooking.service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.irctc.ticketbooking.dao.Bookingdao;
import com.irctc.ticketbooking.dao.Passengerdao;
import com.irctc.ticketbooking.dto.Bookingdto;
import com.irctc.ticketbooking.dto.Passengerdto;
import com.irctc.ticketbooking.Exception.TicketAvailabilityException;
import com.irctc.ticketbooking.model.Booking;
import com.irctc.ticketbooking.model.Composite;
import com.irctc.ticketbooking.model.Passenger;
import com.irctc.ticketbooking.model.Train;



@Service
public class BookingService {
	ModelMapper mapper = new ModelMapper();

	@Autowired
	Bookingdao bookingdao;

	@Autowired
	Passengerdao passengerdao;
	@Autowired
	RestTemplate restTemplate;
	Booking book=new Booking();
	Train newTrain = new Train();

	final String uri = "http://localhost:8081/train/search/id/date/{trainId}/{date}";

	

	public Booking booking(int userId, Composite composite, Bookingdto bookingdto) throws Exception {
		Train trainDetail = restTemplate.getForObject(
				"http://localhost:8081/train/search/id/date/" + composite.getTrainId() + "/" + composite.getDate(),
				Train.class);

		if (trainDetail.getTotalSeats() > book.getNoOfSeats()) {
		//	restTemplate.postForObject("http://localhost:8081/train/updateSeats/"+(trainDetail.getTotalSeats()-book.getNoOfSeats())+"/"+composite.getTrainId()+"/"+composite.getDate(),trainDetail,Train.class ) ;
			double count = bookingdto.getNoOfSeats();
			book.setCost(trainDetail.getCost() * count);
			book.setBookingTime(trainDetail.getStartTime());
			book.setBookingDate(trainDetail.getComposite().getDate());
			book.setSource(trainDetail.getSource());
			book.setDestination(trainDetail.getDestination());
			book.setTrainId(composite.getTrainId());
			book.setUserId(userId);
			 Booking bookingSeat=mapper.map(bookingdto, Booking.class);
			 book.setNoOfSeats(bookingSeat.getNoOfSeats());
			return bookingdao.save(book);
			
		} else {
			throw new Exception();
		}
	}

	public String checkAvailability(Composite key, int noOfSeats) {
		Train trainDetail = restTemplate.getForObject(
				"http://localhost:8081/train/search/id/date/" + key.getTrainId() + "/" + key.getDate(), Train.class);

		if (trainDetail.getTotalSeats() > noOfSeats) {
			return "Tickets are available";
		} else {
			throw new TicketAvailabilityException("No tickets Available");
		}
	}

	public String deleteBooking(int bookingId) {
		Passenger passenger = passengerdao.findById(bookingId).orElse(null);
		Booking book = bookingdao.findById(passenger.getUserId()).orElse(null);
			book.setNoOfSeats(book.getNoOfSeats() - 1);
			bookingdao.save(book);
		
		passengerdao.delete(passenger);
		return "Successfully Cancelled your Ticket :" + bookingId;
	}
	
	
	public List<Passenger> addedPassenger(Passenger[] passengersList, int userId) {
		List<Passenger> passengerInfo = new ArrayList<>();
		Booking book = bookingdao.findById(userId).orElse(null);
		String Id = book.getTrainId();
		LocalDate date = book.getBookingDate();
		Train trainDetail = restTemplate.getForObject("http://localhost:8081/train/search/id/date/" + Id + "/" + date,
				Train.class);
		for (int i = 0; i < book.getNoOfSeats(); i++) {
			passengersList[i].setUserId(userId);
			passengersList[i].setClassType(trainDetail.getClassType());
			passengersList[i].getPassengerName();
			passengersList[i].getPassengerAge();
			passengerInfo.add(passengersList[i]);
			passengerdao.save(passengersList[i]);
		}
		return passengerInfo;
	}

	public List<Passenger> addPassenger(Passengerdto[] passengersdto, int userId) {
		List<Passenger> passengerInfo = new ArrayList<>();
		Booking book = bookingdao.findById(userId).orElse(null);
		String Id = book.getTrainId();
		LocalDate date = book.getBookingDate();
		Train trainDetail = restTemplate.getForObject("http://localhost:8081/train/search/id/date/" + Id + "/" + date,
				Train.class);
		Passenger passenger[]=new Passenger[book.getNoOfSeats()];
		Passenger passengersList[]=new Passenger[book.getNoOfSeats()];
		for (int i = 0; i < book.getNoOfSeats(); i++) {
			passenger[i].setUserId(userId);
			passenger[i].setClassType(trainDetail.getClassType());
			passengersList=mapper.map(passengersdto, Passenger.class);
			passenger[i].setPassengerName(passengersList[i].getPassengerName());
			passenger[i].setPassengerAge(passengersList[i].getPassengerAge());
			passengerInfo.add(passenger[i]);
			

			passengerdao.save(passenger[i]);
		}
		return passengerInfo;
	}
}
