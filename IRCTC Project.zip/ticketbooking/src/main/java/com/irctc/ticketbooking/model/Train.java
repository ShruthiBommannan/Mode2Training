package com.irctc.ticketbooking.model;

import java.io.Serializable;
import java.time.LocalTime;

public class Train implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Composite composite;

	String trainName;
	String source;
	String destination;

	String classType;
	int totalSeats;
	double cost;
	LocalTime startTime;
	LocalTime endTime;

	public Train() {
		super();
	}

	public Train(Composite composite, String trainName, String source, String destination, String classType,
			int totalSeats, double cost, LocalTime startTime, LocalTime endTime) {
		super();
		this.composite = composite;
		this.trainName = trainName;
		this.source = source;
		this.destination = destination;
		this.classType = classType;
		this.totalSeats = totalSeats;
		this.cost = cost;
		this.startTime = startTime;
		this.endTime = endTime;
	}

	public LocalTime getStartTime() {
		return startTime;
	}

	public void setStartTime(LocalTime startTime) {
		this.startTime = startTime;
	}

	public LocalTime getEndTime() {
		return endTime;
	}

	public void setEndTime(LocalTime endTime) {
		this.endTime = endTime;
	}

	public String getTrainName() {
		return trainName;
	}

	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Composite getComposite() {
		return composite;
	}

	public void setComposite(Composite composite) {
		this.composite = composite;
	}

	public String getClassType() {
		return classType;
	}

	public void setClassType(String classType) {
		this.classType = classType;
	}

	public int getTotalSeats() {
		return totalSeats;
	}

	public void setTotalSeats(int totalSeats) {
		this.totalSeats = totalSeats;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

}
