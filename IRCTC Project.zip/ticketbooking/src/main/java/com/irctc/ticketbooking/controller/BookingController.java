package com.irctc.ticketbooking.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.irctc.ticketbooking.dto.Bookingdto;
import com.irctc.ticketbooking.dto.Passengerdto;
import com.irctc.ticketbooking.model.Booking;
import com.irctc.ticketbooking.model.Composite;
import com.irctc.ticketbooking.model.Passenger;
import com.irctc.ticketbooking.model.Train;
import com.irctc.ticketbooking.service.BookingService;

@RestController
public class BookingController {
	@Autowired
	BookingService bookingService;
	@Autowired
	RestTemplate restTemplate;

	@GetMapping(value = "/book/checkAvailability/{trainId}/{date}/{noOfSeats}")
	public String TicketAvailability(@PathVariable String trainId,
			@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date, @PathVariable int noOfSeats) {
		Composite key = new Composite(trainId, date);
		String available = bookingService.checkAvailability(key, noOfSeats);
		return available;

	}

	@PostMapping(value = "/book/ticket/{userId}/{trainId}/{date}")
	public Booking ticketBooking(@PathVariable int userId, @PathVariable String trainId,
			@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date, @RequestBody Bookingdto bookingdto)
			throws Exception {
		Composite id = new Composite(trainId, date);

		return bookingService.booking(userId, id, bookingdto);

	}

	@DeleteMapping(value = "/book/cancel/{bookingId}")
	public String cancelTicket(@PathVariable int bookingId) {
		String cancel = bookingService.deleteBooking(bookingId);
		return cancel;

	}

	@PostMapping(value = "/book/train/addPassengerDetails/{userId}", consumes = "application/json")
	public List<Passenger> passengerInfo(@PathVariable int userId, @RequestBody Passenger[] passenger) {

		return bookingService.addedPassenger(passenger, userId);
	}

	@PostMapping(value = "/book/train/addPassenger/{userId}", consumes = "application/json")
	public List<Passenger> passengerInformation(@PathVariable int userId, @RequestBody Passengerdto[] passengersdto) {

		return bookingService.addPassenger(passengersdto, userId);
	}
	
}
