package com.irctc.ticketbooking.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.irctc.ticketbooking.model.Booking;
import com.irctc.ticketbooking.model.Train;

@Repository
public interface Bookingdao extends CrudRepository<Booking, Integer> {
	@Query(value = "select * from train t", nativeQuery = true)
	public List<Train> listTrain();
}
