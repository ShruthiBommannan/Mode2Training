package com.irctc.ticketbooking.model;

import java.time.LocalDate;
import java.time.LocalTime;

import javax.persistence.Entity;

import javax.persistence.Id;

import javax.persistence.Table;

@Entity
@Table(name = "bookingTickets")

public class Booking {

	String trainId;
	@Id
	int userId;

	String source;
	String destination;
	LocalDate bookingDate;
	LocalTime bookingTime;
	int noOfSeats;
	double cost;

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public Booking(String trainId, int userId, String source, String destination, LocalDate bookingDate,
			LocalTime bookingTime,
			int noOfSeats /* , List<Passenger> passenger */) {
		super();
		this.trainId = trainId;
		this.userId = userId;
		this.source = source;
		this.destination = destination;
		this.bookingDate = bookingDate;
		this.bookingTime = bookingTime;
		this.noOfSeats = noOfSeats;

	}

	public Booking() {
		super();

	}

	public String getTrainId() {
		return trainId;
	}

	public void setTrainId(String trainId) {
		this.trainId = trainId;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public LocalDate getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(LocalDate bookingDate) {
		this.bookingDate = bookingDate;
	}

	public LocalTime getBookingTime() {
		return bookingTime;
	}

	public void setBookingTime(LocalTime bookingTime) {
		this.bookingTime = bookingTime;
	}

	public int getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}

}
