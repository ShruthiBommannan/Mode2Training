package com.irctc.trainSearch.service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.irctc.trainSearch.dao.Traindao;
import com.irctc.trainSearch.exception.TrainNotFoundException;
import com.irctc.trainSearch.model.Composite;
import com.irctc.trainSearch.model.Train;

@Service
public class TrainService {
	@Autowired
	Traindao traindao;

	public List<Train> listTrain(LocalDate date, String source, String destination) {
		int flag = 0;
		List<Train> details = traindao.listTrain(date, source, destination);
		if (!(details.isEmpty())) {
			flag = 1;
			return details;
		}
		if (flag == 0) {
			throw new TrainNotFoundException("Train not found");
		}
		return null;

	}

	public List<Train> searchByTrainId(String trainId) {
		int flag = 0;
		List<Train> details = traindao.searchByTrainId(trainId);
		if (!(details.isEmpty())) {
			flag = 1;
			return details;
		}
		if (flag == 0) {
			throw new TrainNotFoundException("Train not found");
		}
		return null;

	}

	public String addTrain(Train train) {
		traindao.save(train);
		return "Train Details added Successfully!!!";

	}

	public Iterable<Train> getTrains(Train train) {

		return traindao.findAll();

	}

	public Optional<Train> searchByTrainIdandDate(String trainId, LocalDate date) {
		int flag = 0;
		Composite composite = new Composite(trainId, date);
		Optional<Train> details = traindao.findById(composite);
		if ((details.isPresent())) {
			flag = 1;
			return details;
		}
		if (flag == 0) {
			throw new TrainNotFoundException("Train not found");
		}
		return null;
	}

	public int updateSeats(int totalSeats, String trainId, LocalDate date) {
		return traindao.updateSeats(totalSeats, trainId, date);
	}

}
