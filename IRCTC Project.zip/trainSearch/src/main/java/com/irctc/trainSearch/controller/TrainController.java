package com.irctc.trainSearch.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.irctc.trainSearch.model.Train;
import com.irctc.trainSearch.service.TrainService;

@RestController
public class TrainController {
	@Autowired
	TrainService trainService;
	Train train = new Train();

	@GetMapping(value = "/train/search/{date}/{source}/{destination}")
	public ResponseEntity<List<Train>> getTrain(
			@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date, @PathVariable String source,
			@PathVariable String destination) {
		List<Train> searchTrain = trainService.listTrain(date, source, destination);
		return new ResponseEntity<List<Train>>(searchTrain, new HttpHeaders(), HttpStatus.OK);
	}

	@GetMapping(value = "/train/searching/{trainId}")
	public List<Train> searchByTrainId(@PathVariable String trainId) {
		List<Train> searchTrainById = trainService.searchByTrainId(trainId);
		return searchTrainById;

	}

	@PostMapping(value = "/train/add")
	public ResponseEntity<String> addTrainDetails(@RequestBody Train train) {
		trainService.addTrain(train);
		return new ResponseEntity<>("Added Train Details", HttpStatus.OK);
	}

	@GetMapping(value = "/train/getAll")
	public Iterable<Train> getDetails(Train train) {
		return trainService.getTrains(train);

	}

	@GetMapping(value = "/train/search/id/date/{trainId}/{date}")
	public Optional<Train> searchByTrainIdandDate(@PathVariable String trainId,
			@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
		Optional<Train> searchTrainById = trainService.searchByTrainIdandDate(trainId, date);
		return searchTrainById;

	}

	@PostMapping(value = "/train/updateSeats/{totalSeats}/{trainId}/{date}")
	public String updateTrainSeats(@PathVariable int totalSeats, @PathVariable String trainId,
			@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
		trainService.updateSeats(totalSeats, trainId, date);
		return "Updated successfully";

	}

}
