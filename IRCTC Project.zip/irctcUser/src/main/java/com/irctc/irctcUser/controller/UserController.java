package com.irctc.irctcUser.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.irctc.irctcUser.dto.UserRegisterdto;
import com.irctc.irctcUser.dto.Userdto;
import com.irctc.irctcUser.model.User;

import com.irctc.irctcUser.service.UserService;

@RestController
public class UserController {
	@Autowired
	UserService userService;
	@Autowired
	RestTemplate restTemplate;

	@PostMapping(value = "/user/register")
	public ResponseEntity<String> registerUser(@RequestBody UserRegisterdto userregisterdto) {
		String register = userService.addUser(userregisterdto);
		return new ResponseEntity<>(register, HttpStatus.OK);
	}

	@PostMapping(value = "/user/login")
	public String loginUser(@RequestBody Userdto userdto) {
		String login = userService.login(userdto);
		return login;
	}

}
