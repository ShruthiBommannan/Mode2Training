package com.irctc.irctcUser.controller;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.irctc.irctcUser.model.Train;

@RestController
public class SearchController {
	@Autowired
	RestTemplate restTemplate;

	@RequestMapping(value = "user/train/find/{date}/{source}/{destination}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public List<Train> getTrainListbySource(@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date,
			@PathVariable String source, @PathVariable String destination) {

		String uri = "http://localhost:8081/train/search/" + date + "/" + source + "/" + destination;
		return restTemplate.getForObject(uri, List.class);
	}

	@RequestMapping(value = "user/train/findbyId/{trainId}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public List<Train> getTrainListbyIds(@PathVariable String trainId) {
		String uri = "http://localhost:8081/train/searching/" + trainId;
		return restTemplate.getForObject(uri, List.class);
	}

	@RequestMapping(value = "user/train/findby/id/date/{trainId}/{date}", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public Optional<Train> getTrainListbyDate(@PathVariable String trainId,
			@PathVariable @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
		String uri = "http://localhost:8081/train/search/id/date/" + trainId + "/" + date;
		return restTemplate.getForObject(uri, Optional.class);
	}
}
