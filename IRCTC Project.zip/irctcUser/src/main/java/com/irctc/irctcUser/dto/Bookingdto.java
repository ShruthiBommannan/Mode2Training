package com.irctc.irctcUser.dto;

public class Bookingdto {
	int noOfSeats;

	public Bookingdto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Bookingdto(int noOfSeats) {
		super();
		this.noOfSeats = noOfSeats;
	}

	public int getNoOfSeats() {
		return noOfSeats;
	}

	public void setNoOfSeats(int noOfSeats) {
		this.noOfSeats = noOfSeats;
	}

}
