package com.springmvc.pack.controller;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.springmvc.pack.model.Customer;
import com.springmvc.pack.service.CustomerService;



@Controller
public class CustomerController {
	
	private static final Logger logger = LoggerFactory.getLogger(CustomerController.class);
	
	@Autowired
	private CustomerService customerService;
	
	
	private Map<String, Customer> customer = null;

	public CustomerController() {
		customer = new HashMap<String, Customer>();
	}
	
	
	@ModelAttribute("customer")
	public Customer createUserModel() {
		return new Customer();
	}
	@RequestMapping(value = "/add", method = RequestMethod.GET)
	public String addCustomer(Model model) {
		logger.info("Returning cust_details.jsp page");
		// model.addAttribute("user", new User());
		return "cust_details";
	}
	@RequestMapping(value = "/submit", method = RequestMethod.POST)
	public String saveCustomerAction(@ModelAttribute("customer") @Validated Customer customer, BindingResult bindingResult,
			Model model) {
	
		if (bindingResult.hasErrors()) {
			logger.info("Returning Registration page");
			return "cust_details";
		}
		logger.info("Returning cust_success.jsp page");
		model.addAttribute("customer", customer);
		// customers.put(customer.getEmail(), customer);
		this.customerService.saveDetails(customer);
		return "cust_success";
	}
}