package com.springmvc.pack.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.springmvc.pack.dao.CustomerDao;
import com.springmvc.pack.model.Customer;

@Service
public class CustomerService {
	@Autowired
	private CustomerDao customerDao;
	
	Generation generate=new Generation();
	
	@Transactional
	public void saveDetails(Customer cust) {
		
		cust.setAcc(generate.accNo());
		cust.setId(generate.custId());
		cust.setPasswd(generate.password(8));
		customerDao.saveUser(cust);
	}
}
