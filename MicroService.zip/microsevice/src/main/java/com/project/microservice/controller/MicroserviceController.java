package com.project.microservice.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.project.microservice.model.CustomerDto;
import com.project.microservice.model.Movie;
import com.project.microservice.service.MicroserviceService;


@RestController
public class MicroserviceController {
	
	@Autowired
	MicroserviceService microservice;

	@RequestMapping(value = "movie/display", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public List<Movie> getMovieDetails() {
		return microservice.getMovieDetails();
	}

	@RequestMapping(value = "customer/display", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.GET)
	public List<CustomerDto> getCustomerDetails() {
		return microservice.getCustomerDetails();
	}
	

}
