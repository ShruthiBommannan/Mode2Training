package com.project.microservice.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.project.microservice.model.CustomerDto;
import com.project.microservice.model.Movie;

@Service
public class MicroserviceService {
	//To display the movie details 
	public List<Movie> getMovieDetails() {

		RestTemplate restTemplate = new RestTemplate();
		List<Movie> result = restTemplate.getForObject("http://localhost:9090/movie/getAll",List.class);
		return result;
	}
	//To display the customer details
	public List<CustomerDto> getCustomerDetails() {
		RestTemplate restTemplate = new RestTemplate();

		List<CustomerDto> result = restTemplate.getForObject("http://localhost:9092/customer/getAll",List.class);
		return result;
	}
}
