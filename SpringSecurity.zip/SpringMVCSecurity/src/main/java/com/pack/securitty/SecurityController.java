package com.pack.securitty;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class SecurityController {
	
	//To show the user page
	@RequestMapping(value = "/user", method = RequestMethod.GET)
	public String securityModel(Model model) {
		System.out.println("Returning user.jsp page");
		return "user";
	}
	//To show the admin page..Only admin can use
	@RequestMapping(value = "/admin", method = RequestMethod.GET)
	public String securityModelll(Model model) {
		System.out.println("Returning admin.jsp page");
		return "admin";
	}
	
	//Using Internationalization displaying details
	@RequestMapping(value = "/get", method = RequestMethod.GET)
	public String language() {
		System.out.println("Returning details.jsp page");
		return "details";
	}


}
