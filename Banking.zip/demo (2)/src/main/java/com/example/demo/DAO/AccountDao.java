package com.example.demo.DAO;

import org.springframework.data.repository.CrudRepository;

import com.example.demo.model.Account;
import com.example.demo.model.Customer;

public interface AccountDao extends CrudRepository<Account,String>{
	
}
