package com.example.demo.DAO;


import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.example.demo.model.Customer;
import com.example.demo.model.Transaction;

public interface TransactionDao extends CrudRepository<Transaction,String>,PagingAndSortingRepository<Transaction,String>{

	

}
