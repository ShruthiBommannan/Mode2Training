package com.example.demo.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "beneficiary")
public class Beneficiary {
	@Id
	@Column(name = "bankaccNo")
	String bankaccNo;
	@Column(name = "ifscCode")
	String ifscCode;
	@Column(name = "customerId")
	Integer customerId;
	public String getBankaccNo() {
		return bankaccNo;
	}
	public void setBankaccNo(String bankaccNo) {
		this.bankaccNo = bankaccNo;
	}
	public String getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}
	public Integer getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}
	

}
