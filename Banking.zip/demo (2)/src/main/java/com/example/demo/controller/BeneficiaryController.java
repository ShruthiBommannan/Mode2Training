package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Beneficiary;
import com.example.demo.service.BeneficiaryService;

@RestController
public class BeneficiaryController {
	@Autowired
	BeneficiaryService BeneficiaryService;

@RequestMapping(value="/addbeneficiaryDetails",method=RequestMethod.POST)
public String addbeneficiary(@RequestBody Beneficiary ben) {
	return BeneficiaryService.addBenefit(ben);
}
@RequestMapping(value="/findbeneficiaryDetails/{ifscCode}",method=RequestMethod.GET)
public Beneficiary findbeneficiary(@PathVariable String ifscCode) {
	
	Beneficiary bene= BeneficiaryService.findbenefit(ifscCode);
	return bene;
}

}
