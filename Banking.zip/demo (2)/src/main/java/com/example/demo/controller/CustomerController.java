package com.example.demo.controller;

import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dto.CustomerDto;
import com.example.demo.model.Customer;
import com.example.demo.service.CustomerServiceImpl;

@RestController
public class CustomerController {
	@Autowired
	CustomerServiceImpl custservice;
	ModelMapper map=new ModelMapper();
	@PostMapping(value="customer/add")
	public String addCustomerDetails(@RequestBody Customer customer){
		String str=custservice.addCustomerDetails(customer);
		return str;
	}
	
	@GetMapping(value="customer/getAll")
	public List<CustomerDto> getAllcustomers(){
	return	custservice.getAllCustomers();
		
	}
	@PostMapping(value="customer/delete/{custid}")
	public void deleteCustomers(@PathVariable(value="custid") Integer id){
		custservice.deleteCustomers(id);
		
		
	}
	@PostMapping(value="customer/update/{custid}")
	public void UpdateCustomers(@PathVariable(value="custid") Integer id,@RequestBody Customer customer){
		custservice.updateCustomer(id,customer);
				
	}
	@GetMapping(value="customer/get/{custid}")
	public Customer getById(@PathVariable(value="custid") Integer id){
		Customer cust=custservice.getCustomerById(id);
		return cust;
	}
	@GetMapping(value="customer/sortAge")
    public ResponseEntity<List<Customer>> getAllEmployees(
                  
                        @RequestParam(defaultValue = "age") String sortBy)
    {
        List<Customer> list = custservice.getAllValue(sortBy);
 
        return new ResponseEntity<List<Customer>>(list, new HttpHeaders(), HttpStatus.OK);
    }
	
}
