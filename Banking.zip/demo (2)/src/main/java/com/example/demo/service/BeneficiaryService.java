package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.BeneficiaryDao;
import com.example.demo.model.Beneficiary;

@Service
public class BeneficiaryService {
	@Autowired
	BeneficiaryDao bdao;
	
	//To add beneficiary for the user
	public String addBenefit(Beneficiary benefit) {
		bdao.save(benefit);
		return "added";
	}
	
	//To find the details of beneficiary by giving ifsc code
	public Beneficiary findbenefit(String ifscCode) {
		/*
		 * String s="";
		 * //System.out.println(bdao.findByifscCodeAndbankaccNo(ifscCode,s).
		 * getCustomerId());
		 */		return bdao.findByifscCode(ifscCode);
		}

}
