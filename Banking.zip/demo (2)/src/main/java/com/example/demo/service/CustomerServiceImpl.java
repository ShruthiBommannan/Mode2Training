package com.example.demo.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.example.demo.DAO.CustomerDao;
import com.example.demo.dto.CustomerDto;
import com.example.demo.model.Customer;
@Service
public class CustomerServiceImpl {
	@Autowired
	CustomerDao custDao;
	ModelMapper mapper=new ModelMapper();
	List<CustomerDto> list=new ArrayList<CustomerDto>();
	private int accno=100000000;
	private int cust=1;
	
	//To add the customer by providing necessary details
	public String addCustomerDetails(Customer customer){
		if(customer.getAge()>=21){
				//customer.setAccnum("SBI"+(accno++));
				customer.setEmpId((cust++));
				customer.setPassword("HCL"+customer.getcustId());
				custDao.save(customer);
				return "Successful registered";
		}
		else{
			return "Age should be greater than 21";
		}
		
	}
	
	//To update the customer details
	public void updateCustomer(int id,Customer customer){
			Customer customer1 = custDao.findById(id).orElse(null);
			customer1.setJob(customer.getJob());
			customer1.setEmail(customer.getEmail());
			customer1.setPhno(customer.getPhno());
			custDao.save(customer1);
	}
	
	//To get All customer Details
	public List<CustomerDto> getAllCustomers(){
		  custDao.findAll().forEach(customer->convertTo(customer));
		  return list;
	}
	private void convertTo(Customer customer) {
		list.add(mapper.map(customer,CustomerDto.class));
		
	}
	
	//To delete the customer details with respect to ID
	public String deleteCustomers(int id){
		custDao.deleteById(id);
		return "delete Successfully";
	}
	//To get the customer details by providing ID
	public Customer getCustomerById(int id){
		return custDao.findById(id).orElse(null);
		
	}

	public List<Customer> getAllValue(String sortBy) {
		Sort sortOrder = Sort.by("age");
		 
		List<Customer> list =(List<Customer>) custDao.findAll(sortOrder);
		 
		return list;
	}
	
}
