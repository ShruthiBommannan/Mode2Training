package com.example.demo.DAO;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.Customer;

@Repository
public interface CustomerDao extends CrudRepository<Customer,Integer>,PagingAndSortingRepository<Customer,Integer>{
	


}
