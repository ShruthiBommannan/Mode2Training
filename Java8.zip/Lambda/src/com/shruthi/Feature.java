package com.shruthi;

import java.util.Arrays;
import java.util.Collection;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Feature {

	public static void main(String[] args) {
		long count = Stream.of("how", "to", "do", "in", "java").count();
		System.out.printf("There are %d elements in the stream %n", count);
		///////////////////////////////////////////////////////////////////
		// Convert stream of strings to array
		Stream<String> tokenStream = Arrays.asList("A", "B", "C", "D").stream(); // stream

		String[] tokenArray = tokenStream.toArray(String[]::new); // array

		System.out.println(Arrays.toString(tokenArray));
		//////////////////////////////////////////////////////////////////
		Stream<String> stream = Stream.of("one", "two", "three", "four");

		boolean match = stream.anyMatch(s -> s.contains("four"));

		System.out.println(match); // true
		/////////////////////////////////////////////////////////////
		Integer maxNumber = Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9).max(Comparator.comparing(Integer::valueOf)).get();

		Integer minNumber = Stream.of(1, 2, 3, 4, 5, 6, 7, 8, 9).min(Comparator.comparing(Integer::valueOf)).get();

		System.out.println("maxNumber = " + maxNumber);
		System.out.println("minNumber = " + minNumber);
		//////////////////////////////////////////////////////////////////////////////////
		List<Persons> persons = Arrays.asList(new Persons(1, "Shruthi", "Bommannan", 18544),
				new Persons(2, "Balaji", "Devaraj", 25000), new Persons(3, "Ravi", "Bommannan", 1234),
				new Persons(4, "Priya", "Ravi", 1600));
		Optional<Persons> bal = persons.stream().reduce((c1, c2) -> c1.getBalance() > c2.getBalance() ? c1 : c2);
		bal.ifPresent(System.out::println);
		/////////////////////////////////////////////////////////////////////////////////////
		// Creating a list of Prime Numbers
		List<Integer> PrimeNumbers = Arrays.asList(5, 7, 11, 13);

		// Creating a list of Odd Numbers
		List<Integer> OddNumbers = Arrays.asList(1, 3, 5);

		// Creating a list of Even Numbers
		List<Integer> EvenNumbers = Arrays.asList(2, 4, 6, 8);

		List<List<Integer>> listOfListofInts = Arrays.asList(PrimeNumbers, OddNumbers, EvenNumbers);

		System.out.println("The Structure before flattening is : " + listOfListofInts);

		// Using flatMap for transformating and flattening.
		List<Integer> listofInts = listOfListofInts.stream().flatMap(list -> list.stream())
				.collect(Collectors.toList());

		System.out.println("The Structure after flattening is : " + listofInts);
		/////////////////////////////////////////////////////////////////////////////////////////////
		List<Integer> list = Arrays.asList(1, 2, 3, 4, 5);

		List<Integer> newList = list.stream().peek(System.out::println).collect(Collectors.toList());

		System.out.println(newList);
		//////////////////////////////////////////////////////////////////////////////////////////////////
		Collection<String> list1 = Arrays.asList("A", "B", "C", "Z", "R", "Y", "D", "A", "B", "C", "Z");

		// Get collection without duplicate i.e. distinct only
		List<String> distinctElements = list1.stream().distinct().collect(Collectors.toList());

		// Let's verify distinct elements
		System.out.println(distinctElements);
		///////////////////////////////////////////////////////////////////////////////////////////////////

		Persons lokesh = new Persons(1, "Lokesh", "Gupta", 10000);
		Persons shruthi = new Persons(2, "Shruthi", "Clooney", 20000);
		Persons priya = new Persons(3, "Priya", "Kolen", 8500);

		// Add some random persons
		Collection<Persons> list3 = Arrays.asList(lokesh, shruthi, lokesh, priya, shruthi, lokesh);

		// Get distinct objects by key
		List<Persons> distinctElement = list3.stream().filter(distinctByKey(p -> p.getId()))
				.collect(Collectors.toList());

		// Let's verify distinct elements
		System.out.println(distinctElement);

		// Utility function

	}

	public static <T> Predicate<T> distinctByKey(Function<? super T, Object> keyExtractor) {
		Map<Object, Boolean> map = new ConcurrentHashMap<>();
		return t -> map.putIfAbsent(keyExtractor.apply(t), Boolean.TRUE) == null;
	}

}
