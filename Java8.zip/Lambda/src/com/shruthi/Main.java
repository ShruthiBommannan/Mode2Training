package com.shruthi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Main {

	@SuppressWarnings("null")
	public static void main(String args[]) {

		MathOperation fo1 = (a, b) -> b - a;
		System.out.println("Subtraction is:" + fo1.sub(5, 10));
		MathOperatiion fo = (a, b) -> a + b;
		System.out.println("addition is:" + fo.add(5, 10));
		dis m = () -> {
			System.out.println("executing");
		};
		m.display();
		Person p = new Person(10, "Logesh");
		Person p1 = new Person(20, "Shruthi");
		Person p2 = new Person(22, "Priya");
		Person p3 = new Person(25, "Sai");
		List<Person> l = new ArrayList<Person>();
		l.add(p);
		l.add(p1);
		l.add(p2);
		l.add(p3);
		l.forEach(i -> {
			if (i.age > 20)
				System.out.println(i.name);
		});
		l.forEach(li -> {
			if (li.name.startsWith("S"))
				System.out.println(li.name);
		});
		// l.forEach(lie->{if(lie.name.matches("^[P]"))System.out.println(lie.name);});
		List<Integer> b = new ArrayList<Integer>();
		b.add(2);
		b.add(3);
		b.add(15);
		b.add(22);
		b.add(12);
		b.add(24);
		b.add(10);
		b.add(19);
		b.add(17);
		b.add(18);
		System.out.println("Without using lambda..");
		b.forEach(c -> {
			if (c % 2 == 0)
				System.out.println(c);
		});
		b.stream().filter(x -> x % 2 == 0).forEach(System.out::println);
		/*
		 * System.out.println("Without using lambda.."); for(int
		 * z=0;z<b.size();z++){ if(b[z]%2==0) { System.out.println(z); } }
		 */
		List<String> s = Arrays.asList("", "one", "two", "", "three", "", "");
		/*
		 * s.add(""); s.add("one"); s.add("two"); s.add(""); s.add("three");
		 * s.add(""); s.add("four");
		 */
		s.stream().filter(ep -> !ep.isEmpty()).forEach(System.out::println);
		/*
		 * List<Integer>
		 * sb=Arrays.asList(12345,23456,34567,45678,234567,345678,908765);
		 */
		/*
		 * Scanner sc = new Scanner(System.in); System.out.println(
		 * "Enter how many no to be entered:"); int a = sc.nextInt(); int[]
		 * numbers = new int[a]; for (int i = 0; i < a; i++) {
		 * System.out.println("Please enter"+ a +"number"); numbers[i] =
		 * sc.nextInt(); }
		 */
		/*
		 * Scanner sc = new Scanner(System.in); int a = sc.nextInt(); int[]
		 * numbers = new int[a]; System.out.println("Please enter"+ a
		 * +"number"); for (int i = 0; i < a; i++) { numbers[i] = sc.nextInt();
		 * } String str="SBI"; String[] valid = new String[5] ; int[] invalid =
		 * new int[10]; for (int i = 0; i < a; i++) {
		 * 
		 * int c=Integer.toString(numbers[i]).length(); if(c==5){
		 * 
		 * valid[i]="SBI"+Integer.toString(numbers[i]);
		 * System.out.println("SBI"+Integer.toString(numbers[i])+" is valid"); }
		 * else{ invalid[i]=numbers[i];
		 * System.out.println("SBI"+Integer.toString(numbers[i])+" is invalid");
		 * 
		 * } }
		 */
		List<Integer> num = new ArrayList<Integer>();
		Scanner sca = new Scanner(System.in);
		System.out.println("Please enter number");
		for (int i = 0; i < 10; i++) {
			num.add(sca.nextInt());
		}
		List<String> validate = num.stream().map(x -> "SBI" + x).filter(x -> x.length() == 8)
				.collect(Collectors.toList());

		List<String> invalidate = num.stream().map(x -> "SBI" + x).filter(x -> x.length() != 8)
				.collect(Collectors.toList());
		System.out.println("valid accounts are:" + validate);
		System.out.println("invalid accounts are:" + invalidate);
		System.out.println("valid accounts are:" + validate.size());
		Customer[] c = new Customer[20];
		String nameList;
		int age;
		long phoneNo;
		float balance;
		float amount;
		String accNo = null;
		List<Customer> listed = new ArrayList<Customer>();
		for (int i = 0; i < validate.size(); i++) {
			nameList = sca.next();
			age = sca.nextInt();
			phoneNo = sca.nextLong();
			accNo = validate.get(i);
			balance = sca.nextFloat();
			// amount=sca.nextFloat();
			// c[i] = new Customer(nameList, age, accNo,
			// phoneNo,balance,amount);
			// Customer cust=new Customer();
			// float RemBalance=cust.withdrwal(balance,amount);
			c[i] = new Customer(nameList, age, accNo, phoneNo, balance);
			listed.add(c[i]);
		}

		List<Customer> ans = listed.stream().filter(x -> (x.name.matches("^[A-Z][a-zA-Z]{2,30}$")) && (x.age >= 18)
				&& ((String.valueOf(x.phoneNo).matches("^[1-9][0-9]{2,10}$"))))

				.collect(Collectors.toList());
		List<Customer> sortedList = ans.stream().sorted(Comparator.comparing(Customer::getName))
				.collect(Collectors.toList());

		System.out.println("Valid accounts are:");
		sortedList.forEach((temp) -> {

			System.out.println("Name:" + temp.name + " " + "Age:" + temp.age + " " + "PhoneNo:" + temp.phoneNo + " "
					+ "AccNo:" + temp.accNo + " " + "balance:" + temp.balance);
		});
		List<Customer> fail = listed.stream().filter(x -> !(x.name.matches("^[A-Z][a-zA-Z]{2,30}$")) && (x.age >= 18)
				&& ((String.valueOf(x.phoneNo).matches("^[1-9][0-9]{2,10}$"))))

				.collect(Collectors.toList());
		System.out.println("Invalid accounts are:");
		fail.forEach((tem) -> {

			System.out.println("Name:" + tem.name + " " + "Age:" + tem.age + " " + "PhoneNo:" + tem.phoneNo + " "
					+ "AccNo:" + tem.accNo + " " + "balance:" + tem.balance);
		});
		int ch = 0;
		int flag = -1;
		System.out.println("Enter user name:");
		String CustomerName = sca.next();
		for (int i = 0; i < ans.size(); i++) {
			if (!(ans.get(i).name.equals(CustomerName))) {
				flag = -1;

			} else {
				flag = i;
				break;
			}

		}
		if (flag == -1) {
			System.out.println("Invalid User..");
		}
		Customer cust = new Customer();

		do {
			if (flag != -1) {
				System.out.println("Enter the choice:");
				System.out.println("1.Withdrawal");
				System.out.println("2.Deposit");
				System.out.println("3.MiniStatement");
				System.out.println("4.Exit");
				ch = sca.nextInt();
				switch (ch) {
				case 1:
					cust.withdrwal(ans, flag);
					break;
				case 2:
					cust.deposit(ans, flag);
					break;
				case 3:
					cust.display(ans, flag);
					break;
				case 4:
					System.out.println("Welcome..Please Visit us again!!!!!!!");
					break;
				default:
					System.out.println(ch + " which you entered is not Valid!!!!");
				}
			}
			  System.out.print("\n---------------------------------------\n");
		} while (!(ch == 4));

		/*
		 * listed.forEach((temp)->{ System.out.println(temp.name+" "+temp.age+
		 * " "+temp.phoneNo+" "+temp.accNo); });
		 */
		/*
		 * for(int i=0;i<validate.size();i++){ Pattern pattern; Matcher matcher;
		 * final String USERNAME_PATTERN = "^[A-Z][a-zA-Z]{2,30}$"; pattern =
		 * Pattern.compile(USERNAME_PATTERN); matcher =
		 * pattern.matcher(listed.get(i).name); if(matcher.matches()==true &&
		 * (String.valueOf(listed.get(i).phoneNo)).length()==10){
		 * if(listed.get(i).age>18){ System.out.println(listed.get(i).accNo+
		 * " is valid"); } else{ System.out.println(listed.get(i).accNo+
		 * " is minor"); } } else{ System.out.println(listed.get(i).accNo+
		 * " is invalid");
		 * 
		 * } }
		 */

		// System.out.println(listed);
		/*
		 * for (int i = 0; i < 1; i++) { ageList.add(sca.nextInt());
		 * 
		 * } for (int i = 0; i < 1; i++) { phoneList.add(sca.nextLine());
		 * 
		 * } for (int i = 0; i < 1; i++) { accList.add(sca.nextLine());
		 * 
		 * }
		 */
		/*
		 * List<String>namevalidate=nameList.stream()
		 * .filter(i->i.matches("^[A-Za-z]$")) .collect(Collectors.toList());
		 * System.out.println(namevalidate);
		 */

	}
}