package com.shruthi;

import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import javax.validation.constraints.NotNull;

@Repeatable(Operate.class)
@interface Operations {
	/*String name="";
	int age=0;
	String accNo="";
	String phoneNo="";
	float balance=0.0f;*/
	@NotNull
	String name();

	int age();

	String accNo();

	@NotNull
	String phoneNo();

	@NotNull
	float balance();
}

@Retention(RetentionPolicy.RUNTIME)
@interface Operate {
	Operations[] value();
}





