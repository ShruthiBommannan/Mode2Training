package com.shruthi;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.stream.Collectors;

@Operations(accNo = "SBI12345", age = 21, balance = 250001, name = "Shruthi", phoneNo = "9952365121")
@Operations(accNo = "SBI23456", age = 22, balance = 234500, name = "Bala", phoneNo = "7708248101")
@Operations(accNo = "SBI34567", age = 17, balance = 90400, name = "balaji", phoneNo = "9994540222")
@Operations(accNo = "SBI45678", age = 18, balance = 150000, name = "Priya", phoneNo = "8903762243")
@Operations(accNo = "SBI56789", age = 28, balance = 123456, name = "Sandhiya", phoneNo = "9940733057")
@Operations(accNo = "SBI67890", age = 35, balance = 345000, name = "Prakash", phoneNo = "865432032")
@Operations(accNo = "SBI68901", age =12, balance = 3500, name = "prakash", phoneNo = "865467032")
public class OperationMain {

	public static void main(String args[]) {
		List<Operations> list = new ArrayList<Operations>();
		Operations[] val = OperationMain.class.getAnnotationsByType(Operations.class);
		for (Operations color : val) {
			System.out.println(color.name() + " " + color.age() + " " + color.accNo() + " " + " " + color.balance()
					+ " " + color.phoneNo());
		}
		for (Operations i : val) {
			list.add(i);
		}
		/*list.forEach((temp) -> {

			System.out.println("Name:" + temp.name() + " " + "Age:" + temp.age() + " " + "PhoneNo:" + temp.phoneNo()
					+ " " + "AccNo:" + temp.accNo() + " " + "balance:" + temp.balance());
		});*/

		List<Operations> ans = list.stream().filter(x -> (x.name().matches("^[A-Z][a-zA-Z]{2,30}$")) && (x.age() >= 18)
				&& ((String.valueOf(x.phoneNo()).matches("^[1-9][0-9]{2,10}$"))))

				.collect(Collectors.toList());
		System.out.println("Valid accounts are:");
		ans.forEach((temp) -> {

			System.out.println("Name:" + temp.name() + " " + "Age:" + temp.age() + " " + "PhoneNo:" + temp.phoneNo()
					+ " " + "AccNo:" + temp.accNo() + " " + "balance:" + temp.balance());
		});
		

		List<Operations> fail = list.stream().filter(x -> (!(x.name().matches("^[A-Z][a-zA-Z]{2,30}$"))
				&& (x.age() >= 18) && ((String.valueOf(x.phoneNo()).matches("^[1-9][0-9]{2,10}$")))))

				.collect(Collectors.toList());
		System.out.println("Invalid accounts are:");
		fail.forEach((tem) -> {

			System.out.println("Name:" + tem.name() + " " + "Age:" + tem.age() + " " + "PhoneNo:" + tem.phoneNo() + " "
					+ "AccNo:" + tem.accNo() + " " + "balance:" + tem.balance());
		});

	}
}
