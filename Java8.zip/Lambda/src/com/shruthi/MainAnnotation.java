package com.shruthi;

public class MainAnnotation {
	 public static void main(String args[]) {
		   Color[] colorArray = User.class.getAnnotationsByType(Color.class);
		   for (Color color : colorArray) {
		    System.out.println(color.name()+" "+color.age());
		   }
	 }
}
