package com.shruthi;

public interface dis {
 public void display();
		
	
}
