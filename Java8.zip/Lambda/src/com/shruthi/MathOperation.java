package com.shruthi;

public interface MathOperation {
	public int sub(int a,int b);
}
