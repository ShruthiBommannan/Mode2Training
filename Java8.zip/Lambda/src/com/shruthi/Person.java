package com.shruthi;

public class Person {
	int age;
	String name;
	public Person() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Person(int age, String name) {
		super();
		this.age = age;
		this.name = name;
	}
	
}
