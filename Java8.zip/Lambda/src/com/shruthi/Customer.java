package com.shruthi;

import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import javax.validation.constraints.NotNull;

public class Customer {

	@NotNull
	String name;
	@NotNull
	
	int age;
	@NotNull
	String accNo;
	@NotNull
	long phoneNo;
	@NotNull
	float balance;
	float amount;
	List<String>mini=new ArrayList<String>();
	public Customer() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Customer(String name, int age, String accNo, long phoneNo,float balance) {
		super();
		this.name = name;
		this.age = age;
		this.accNo = accNo;
		this.phoneNo = phoneNo;
		this.balance=balance;
		
	}
	public float getBalance() {
		return balance;
	}
	public void setBalance(float balance) {
		this.balance = balance;
	}
	public Customer(String nameList, String accNo2, long phoneNo2) {
		// TODO Auto-generated constructor stub
	}
	public Customer(String nameList, int age2, long phoneNo2) {
		// TODO Auto-generated constructor stub
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public void withdrwal(List<Customer> ans,int flag){
		System.out.println("Please enter the amount to be withdrawn");
		Scanner sc = new Scanner(System.in);
		float amount=sc.nextFloat();
		if(ans.get(flag).balance<amount)
		{
			System.out.println("Your balance is less..");
		}
		else{
			balance=ans.get(flag).balance-amount;
			ans.get(flag).balance=balance;
			String s="Withdrawn:"+amount;
			ans.get(flag).mini.add(s);
		}
	}
	public void deposit(List<Customer> ans,int flag) {
		System.out.println("Please enter the amount to be deposited");
		Scanner sc = new Scanner(System.in);
		float deposit=sc.nextFloat();
		balance=ans.get(flag).balance+deposit;
		ans.get(flag).balance=balance;
		String s1="Deposited:"+deposit;
		ans.get(flag).mini.add(s1);
	}
	int k=1;
	public void display(List<Customer> ans,int flag) {
		
		System.out.println("**********Your Transactions*************");
		System.out.println("Name:"+ans.get(flag).name+" "+"age:"+ans.get(flag).age+" "+"PhoneNo:"+ans.get(flag).phoneNo);
		System.out.println("Available balance is "+ans.get(flag).balance);
		for(int i=ans.get(flag).mini.size()-1;i>=0;i--){
			System.out.println(k+". "+ans.get(flag).mini.get(i));
			System.out.println();
			k++;
			if(k==11){
				break;
			}
		}
		
		
		
	}
	
	
	
}
