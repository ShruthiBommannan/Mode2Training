package com.shruthi;

import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.*;

@Repeatable(Colors.class)
@interface Color {
	@NotNull
	String name();
    int age();
}

@Retention(RetentionPolicy.RUNTIME)
@interface Colors {
	Color[] value();
}

@Color(name = "Shruthi", age = 0)
@Color(name = "bala", age = 21)
@Color(name = "Thahir", age = 22)
@Color(name = "Shakti", age = 22)
public class User {
	
}
	
