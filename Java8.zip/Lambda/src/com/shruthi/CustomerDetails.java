package com.shruthi;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
@Retention(RetentionPolicy.RUNTIME)
@interface Customer1{
	
	String name();
	int age();	
}
@Customer1(name="shru",age=21)
public class CustomerDetails {
	
	 public static void main(String args[]) {
		Customer1 cust = CustomerDetails.class.getAnnotation(Customer1.class);
		System.out.println("Name:"+cust.name()+" "+"Age:"+cust.age());
	 }
	 
}
