package com.shruthi;

public interface MathOperatiion {
	public int add(int a,int b);

	
	
}
