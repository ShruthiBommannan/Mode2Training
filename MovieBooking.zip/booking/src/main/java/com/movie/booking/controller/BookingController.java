package com.movie.booking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.movie.booking.model.Booking;

import com.movie.booking.service.BookingService;


@RestController
public class BookingController {
	@Autowired
	BookingService bookingservice;
	@PostMapping(value="/add/booking")
	public Booking addShowDetails(@RequestParam String movieName,@RequestParam String theaterId,@RequestParam String showTime,@RequestParam int userId ){
		return (Booking) bookingservice.addBooking(movieName,theaterId,showTime,userId);
		
	}
}
