package com.movie.booking.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.movie.booking.model.User;
import com.movie.booking.service.UserService;

@RestController
public class UserController {
	@Autowired
	UserService userservice;
	@PostMapping(value="/add/user")
	public String addUserDetails(@RequestBody User user){
		String str=userservice.addUser(user);
		return str;
	}

}
