package com.movie.booking.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movie.booking.dao.Userdao;
import com.movie.booking.model.User;

@Service
public class UserService {
	@Autowired 
	Userdao userdao;
	
	//To add the user info
	public String addUser(User user) {
		userdao.save(user);
		return "Successfully entered the user details";
		
	}
}
