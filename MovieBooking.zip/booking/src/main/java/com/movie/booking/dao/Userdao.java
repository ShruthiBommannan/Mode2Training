package com.movie.booking.dao;

import org.springframework.data.repository.CrudRepository;

import com.movie.booking.model.User;

public interface Userdao extends CrudRepository<User,Long>{

}
