package com.movie.booking.model;


import java.time.LocalDate;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="showtable")
public class Show {
LocalDate date;
@Id
String theaterId;
String morningShow;
String eveningShow;
String noonShow;

public LocalDate getDate() {
	return date;
}
public void setDate(LocalDate date) {
	this.date = date;
}
public String getTheaterId() {
	return theaterId;
}
public void setTheaterId(String theaterId) {
	this.theaterId = theaterId;
}
public String getMorningShow() {
	return morningShow;
}
public void setMorningShow(String morningShow) {
	this.morningShow = morningShow;
}
public String getEveningShow() {
	return eveningShow;
}
public void setEveningShow(String eveningShow) {
	this.eveningShow = eveningShow;
}
public String getNoonShow() {
	return noonShow;
}
public void setNoonShow(String noonShow) {
	this.noonShow = noonShow;
}



}
