package com.movie.booking.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.movie.booking.model.Movie;

import com.movie.booking.service.MovieService;

@RestController
public class MovieController {
	@Autowired
	MovieService movieservice;
	@PostMapping(value="/add/movie")
	public String addMovieDetails(@RequestBody Movie movie){
		String str=movieservice.addMovie(movie);
		return str;
	}
	
	
	@GetMapping(value="movie/getAll")
	public Iterable<Movie> getAllMovie(){
	return	movieservice.getAllMovie();
}
}
