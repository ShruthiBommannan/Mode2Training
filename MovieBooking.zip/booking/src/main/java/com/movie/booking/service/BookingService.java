package com.movie.booking.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movie.booking.dao.Bookingdao;
import com.movie.booking.dao.Showdao;
import com.movie.booking.dao.Theaterdao;
import com.movie.booking.model.Booking;
import com.movie.booking.model.Show;
import com.movie.booking.model.Theater;

@Service
public class BookingService {
	@Autowired 
	Bookingdao bookingdao;
	@Autowired
	Theaterdao theaterdao;
	@Autowired 
	Showdao showdao;
	
	//To book the show by passing the required inputs like moviename,theaterid..etc..
	public Booking addBooking(String movieName,String theaterId,String showTime,int userId) {
		Theater theater= theaterdao.findById(theaterId).orElse(null);
		Show show=showdao.findById(theaterId).orElse(null);
		Booking b=new Booking();
		
		
		b.setUserId(userId);
		b.setShowTime(showTime);
		b.setMovieName(movieName);
		b.setTheaterName(theater.getTheaterName());
		
		b.setDate(show.getDate());
		
		 return bookingdao.save(b);
		
		
		//return "Successfully entered the Booking details";
		
	}
	
	
}
