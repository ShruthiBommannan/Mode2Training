package com.movie.booking.service;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.util.StdDateFormat;
import com.movie.booking.dao.Showdao;
import com.movie.booking.dao.Theaterdao;
import com.movie.booking.dto.Showdto;
import com.movie.booking.dto.TheaterShowdto;
import com.movie.booking.exception.MovieExist;
import com.movie.booking.model.Show;
import com.movie.booking.model.Theater;


@Service
public class ShowService {
	@Autowired 
	Showdao showdao;
	@Autowired 
	Theaterdao theaterdao;
	
	public String addShow(Show show) {
		showdao.save(show);
		return "Successfully entered the Show details";
		
	}
	
	//To check movie is running or not
	public String checkMovie(Showdto showdto){
		int flag=0;
		List<Show> list=(List<Show>) showdao.findAll();
		for(Show s:list) {
			if(showdto.getShowSearch().equalsIgnoreCase(s.getMorningShow())||
					showdto.getShowSearch().equalsIgnoreCase(s.getEveningShow())||
					showdto.getShowSearch().equalsIgnoreCase(s.getNoonShow())) {
				flag=1;
				return "Movie is Running now...!!!";
			}
		}
		if(flag==0) {
			throw new MovieExist("Movie Not Exist!! "+showdto.getShowSearch());
		}
		return null;
		
	}
	
	public List<TheaterShowdto> showingMovie(String movieName, String date1) throws ParseException
	{
		Date date2=new StdDateFormat().parse(date1);
		List<Show> listShow=showdao.finding(movieName,date2);
		Theater theater=new Theater();
		List<TheaterShowdto> list=new ArrayList<>();
		for(Show value:listShow) {
			TheaterShowdto tshowdto=new TheaterShowdto();
			String theaterId=value.getTheaterId();
			theater=theaterdao.findById(theaterId).orElse(null);
			tshowdto.setTheaterName(theater.getTheaterName());
			tshowdto.setPlace(theater.getPlace());
			tshowdto.setMorningShow(value.getMorningShow());
			tshowdto.setNoonShow(value.getNoonShow());
			tshowdto.setEveningShow(value.getEveningShow());
			list.add(tshowdto);
			
			
		}
		
		
		return list;
		
	}
	
	//To show the list where and all the movie is running
	public List<TheaterShowdto> showMovie(String movieName) throws ParseException
	{
		
		List<Show> listShow=showdao.find(movieName);
		Theater theater=new Theater();
		List<TheaterShowdto> list=new ArrayList<>();
		for(Show value:listShow) {
			TheaterShowdto tshowdto=new TheaterShowdto();
			String theaterId=value.getTheaterId();
			theater=theaterdao.findById(theaterId).orElse(null);
			tshowdto.setTheaterName(theater.getTheaterName());
			tshowdto.setPlace(theater.getPlace());
			tshowdto.setMorningShow(value.getMorningShow());
			tshowdto.setNoonShow(value.getNoonShow());
			tshowdto.setEveningShow(value.getEveningShow());
			list.add(tshowdto);
			
			
		}
		
		
		return list;
		
	}
}
