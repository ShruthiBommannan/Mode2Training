package com.movie.booking.dto;

public class TheaterShowdto {
	String theaterName;
	String place;
	String morningShow;
	String eveningShow;
	String noonShow;
	
	public String getTheaterName() {
		return theaterName;
	}
	public void setTheaterName(String theaterName) {
		this.theaterName = theaterName;
	}
	public String getPlace() {
		return place;
	}
	public void setPlace(String place) {
		this.place = place;
	}
	public String getMorningShow() {
		return morningShow;
	}
	public void setMorningShow(String morningShow) {
		this.morningShow = morningShow;
	}
	public String getEveningShow() {
		return eveningShow;
	}
	public void setEveningShow(String eveningShow) {
		this.eveningShow = eveningShow;
	}
	public String getNoonShow() {
		return noonShow;
	}
	public void setNoonShow(String noonShow) {
		this.noonShow = noonShow;
	}
	
	
	
}
