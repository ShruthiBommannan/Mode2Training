package com.movie.booking.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="theater")
public class Theater {
@Id
String theaterId;
String theaterName;
String place;
public String getTheaterId() {
	return theaterId;
}
public void setTheaterId(String theaterId) {
	this.theaterId = theaterId;
}
public String getTheaterName() {
	return theaterName;
}
public void setTheaterName(String theaterName) {
	this.theaterName = theaterName;
}
public String getPlace() {
	return place;
}
public void setPlace(String place) {
	this.place = place;
}

}
