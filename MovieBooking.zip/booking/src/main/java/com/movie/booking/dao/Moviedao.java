package com.movie.booking.dao;
import org.springframework.data.repository.CrudRepository;

import com.movie.booking.model.Movie;
public interface Moviedao extends CrudRepository<Movie,String> {

}
