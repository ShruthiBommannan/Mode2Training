package com.movie.booking.dto;

public class Showdto {
	String showSearch;

	public String getShowSearch() {
		return showSearch;
	}

	public void setShowSearch(String showSearch) {
		this.showSearch = showSearch;
	}
	
	
	
}
