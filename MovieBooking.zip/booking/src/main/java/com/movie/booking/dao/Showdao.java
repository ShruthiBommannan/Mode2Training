package com.movie.booking.dao;

import java.util.Date;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.movie.booking.dto.TheaterShowdto;
import com.movie.booking.model.Show;


public interface Showdao extends CrudRepository<Show,String>{
	
	  @Query(
	  value="select * from showtable s where s.morning_show=?1 or s.noon_show=?1 or s.evening_show=?1"
	  ,nativeQuery=true) public List<Show> find(String moviename);
	 


@Query(value="0",nativeQuery=true)
public List<Show> finding(String moviename,Date date2);
}