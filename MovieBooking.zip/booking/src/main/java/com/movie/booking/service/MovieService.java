package com.movie.booking.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movie.booking.dao.Moviedao;

import com.movie.booking.model.Movie;


@Service
public class MovieService {
	@Autowired 
	Moviedao moviedao;
	
	//To add movie names 
	public String addMovie(Movie movie) {
		moviedao.save(movie);
		return "Successfully entered the movie details";
		
	}
	
	//To display movie name
	public Iterable<Movie> getAllMovie() {
		 Iterable<Movie> list=moviedao.findAll();
		return list;
		
	}
	

}
