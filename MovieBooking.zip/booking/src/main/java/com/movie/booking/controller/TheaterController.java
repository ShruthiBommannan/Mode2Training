package com.movie.booking.controller;



import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.movie.booking.model.Theater;
import com.movie.booking.service.TheaterService;

@RestController
public class TheaterController {
	@Autowired
	TheaterService theaterService;
	@PostMapping(value="/add/theater")
	public String addTheaterDetails(@RequestBody Theater theater){
		String str=theaterService.addTheater(theater);
		return str;
	}
	/*
	 * @GetMapping(value="/theater/get") public List<Theater> Movie() {
	 * List<Theater> p=theaterService.findMovie(); return p; }
	 */
	
	
	
	  @GetMapping(value="/show/get/{movieName}") 
	  public List<Theater> getshow(@PathVariable String movieName) {
		  List<Theater> p=theaterService.find(movieName);
		  return p;
		  }
	 
	  
	
	
	
	/*
	 * @GetMapping(value="/getlist/{movieName}") public List<Theaterdto>
	 * getList(@PathVariable String movieName){ List<Theaterdto>
	 * value=theaterService.theaterDetails(movieName); return value;
	 * 
	 * }
	 */
}
