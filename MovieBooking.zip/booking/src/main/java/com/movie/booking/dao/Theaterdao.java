package com.movie.booking.dao;
import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.movie.booking.model.Show;
import com.movie.booking.model.Theater;
public interface Theaterdao extends CrudRepository<Theater,String>{
	@Query(value="select * from theater t where t.theater_id IN (select s.theater_id from showtable s where s.morning_show=?1 or s.noon_show=?1 or s.evening_show=?1)",nativeQuery=true)
    public List<Theater> find(String moviename);
	
	
	
	  @Query("select s from Show s where s.theaterId like ?1") 
 List<Show> showDetails(String theaterId);
	 
	 
}

