package com.movie.booking.controller;

import java.io.IOException;
import java.text.ParseException;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.movie.booking.dto.Showdto;
import com.movie.booking.dto.TheaterShowdto;
import com.movie.booking.model.Show;

import com.movie.booking.service.ShowService;

@RestController
public class ShowController {
	@Autowired
	ShowService showservice;
	@PostMapping(value="/add/show")
	public String addShowDetails(@RequestBody Show show){
		String str=showservice.addShow(show);
		return str;
	}
	@PostMapping(value="/show/search")
	public String showsearch(@RequestBody Showdto showdto) throws IOException {
		String v=showservice.checkMovie(showdto);
		return v;
		
	}
	@GetMapping(value="/getDetailsMovie")
	public List<TheaterShowdto> findingMovieName(@RequestParam(value="movieName") String movieName,@RequestParam(value="date1") String date1) throws ParseException{
		System.out.println("entering..");
		List<TheaterShowdto> list=showservice.showingMovie(movieName,date1);
		return list;
		
	}
	@GetMapping(value="/getDetails")
	public List<TheaterShowdto> findMovieName(@RequestParam(value="movieName") String movieName) throws ParseException{
		System.out.println("entering..");
		List<TheaterShowdto> list=showservice.showMovie(movieName);
		return list;
		
	}
	
}
