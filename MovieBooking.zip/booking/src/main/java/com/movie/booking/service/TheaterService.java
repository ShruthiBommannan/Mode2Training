package com.movie.booking.service;

import java.util.List;

import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.movie.booking.dao.Theaterdao;
import com.movie.booking.exception.MovieExist;
import com.movie.booking.model.Show;
import com.movie.booking.model.Theater;

@Service
public class TheaterService {
	@Autowired
	Theaterdao theaterdao;

	public String addTheater(Theater theater) {
		theaterdao.save(theater);
		return "Successfully entered the theater details";

	}

	/*
	 * public List<Theater> findMovie() { List<Theater> pList = theaterdao.find();
	 * for (Theater p : pList) System.out.println("Theater " + p.getTheaterId() +
	 * " " + p.getPlace()); return pList; }
	 */

	//To find the details of movie by passing movie name
	 public List<Theater>  find(String movieName) { 
		
		 List<Theater> p=theaterdao.find(movieName);
		return p;
	 }
	
	
}
