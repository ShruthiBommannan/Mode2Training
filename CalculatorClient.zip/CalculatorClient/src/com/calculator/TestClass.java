package com.calculator;

import java.rmi.RemoteException;

import org.apache.axis2.AxisFault;

public class TestClass {

	public static void main(String[] args) {
		try {
			CalculatorStub stub=new CalculatorStub();
			CalculatorStub.Addition params=new CalculatorStub.Addition();
			params.setA(20);
			params.setB(10);
			CalculatorStub.AdditionResponse response=stub.addition(params);
			int result=response.get_return();
			System.out.println("Result is: "+result);
			
			CalculatorStub.Subtraction param=new CalculatorStub.Subtraction();
			param.setA(200);
			param.setB(100);
			CalculatorStub.SubtractionResponse responses=stub.subtraction(param);
			int results=responses.get_return();
			System.out.println("Sub is:"+results);
			
			CalculatorStub.Multlication param1=new CalculatorStub.Multlication();
			param1.setA(200);
			param1.setB(100);
			CalculatorStub.MultlicationResponse responses1=stub.multlication(param1);
			int results1=responses1.get_return();
			System.out.println("Multiplication is:"+results1);
			
			CalculatorStub.Division param2=new CalculatorStub.Division();
			param2.setA(200);
			param2.setB(10);
			CalculatorStub.DivisionResponse responses2=stub.division(param2);
			int results2=responses2.get_return();
			System.out.println("Division is:"+results2);
			
			
		} catch (RemoteException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
